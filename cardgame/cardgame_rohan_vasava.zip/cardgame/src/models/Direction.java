package models;

public enum Direction {
    POSITIVE, NEGATIVE;
}
