package models;

public enum PlayerType {
    HUMAN,BOT,
}
