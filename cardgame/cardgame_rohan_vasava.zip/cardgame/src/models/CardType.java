package models;

public enum CardType {
    NUMBER, ACTION;
}
