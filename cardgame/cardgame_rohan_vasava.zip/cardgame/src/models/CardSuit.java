package models;

public enum CardSuit {
    HEART, CLUB, SPADE, DIAMOND;
}
