package exeptions;

public class DrawPileEmptyException extends Exception{
}
