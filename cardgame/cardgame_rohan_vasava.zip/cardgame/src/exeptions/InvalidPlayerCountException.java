package exeptions;

public class InvalidPlayerCountException extends Exception{
}
